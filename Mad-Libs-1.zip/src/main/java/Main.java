

import java.util.Scanner; // Allows us to use Java's Scanner class

public class Main {
  // Declare a story variable that all methods in the class can uses
  public static String story;

  public static void main(String[] args) {
    // Scanners allow code to read user input
    Scanner reader = new Scanner(System.in);
    // Create variables for words the user will enter
    String season;
    String verb;
    String adjective;
    String noun;
    String timeSpan;

    // Instantiate story: copy Mad Lib template using * for every blank
    story = "When you are in love every day feels like *. The sun is always *, the air feels *, and the birds are always *. You see the world through rose colored *. When you see the person you love your heart *. You can't * because they take your * away. The person you love is always on your * and you can't imagine a * without them.";

    // Ask user to input specified words
    askFor("season");
    // Assign variable to user input
    season = reader.nextLine();
    // Add the word to the story
    addToStory(season);

    // Repeat until story is over 
    askFor("verb ending in -ing");
    verb = reader.nextLine();
    addToStory(verb);

    askFor("adjective");
    adjective = reader.nextLine();
    addToStory(adjective);

    askFor("verb ending in -ing");
    verb = reader.nextLine();
    addToStory(verb);

    askFor("plural noun");
    noun = reader.nextLine();
    addToStory(noun);

    askFor("verb");
    verb = reader.nextLine();
    addToStory(verb);

    askFor("verb");
    verb = reader.nextLine();
    addToStory(verb);

    askFor("noun");
    noun = reader.nextLine();
    addToStory(noun);

    askFor("noun");
    noun = reader.nextLine();
    addToStory(noun);

    askFor("time span (5 days, 2 months, etc)");
    timeSpan = reader.nextLine();
    addToStory(timeSpan);

    // Return the story to your reader!
    System.out.println("\nHere is your Mad Lib! \n" + "\n" + story);
  }

  // Mutates the story by adding word the user gave us
  public static void addToStory(String s) {
    // Find the next blank in the story
    int pos = story.indexOf("*");
    // Fill in the blank: add story up to *, word in place of *, then rest of story 
    story = story.substring(0, pos) + s + story.substring(pos + 1);
  }

  // Makes it easier for us ask user for specified words
  private static void askFor(String word) {
    System.out.println("\nPlease enter a " + word + ":");
  }
}